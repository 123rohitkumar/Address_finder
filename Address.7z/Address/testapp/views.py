from django.shortcuts import render
from .models import Person
from .resources import PersonResource
from tablib import Dataset
from django.contrib import messages
from django.views.generic import TemplateView
from django.http import HttpResponse
#from django.core.files.storage import FileSystemStorage

# Create your views here.

class Home(TemplateView):
    template_name = 'home.html'

#def upload(request):
    # context = {}
    # if request.method == 'POST':
    #     uploaded_file = request.FILES['document']
    #     fs = FileSystemStorage()
    #     name = fs.save(uploaded_file.name,uploaded_file)
    #     context['url'] = fs.url(name)
    # return render(request,'upload.html',context)

def upload(request):
    if request.method == "POST":
        person_resource = PersonResource()
        dataset = Dataset()
        new_person = request.FILES['document']

        if not new_person.name.endswith('xlsx'):
            messages.info(request,'wrong format')
            return render(request,'upload.html')
            print("wrong format")

    

        imported_data = dataset.load(new_person.read(),format='xlsx')
        for data in imported_data:
            value = Person(
                data[0],
                data[1],
                data[2],
                data[3],
                data[4],
                data[5],
                data[6]
                
            )
            value.save()

    return render(request,'upload.html')    














