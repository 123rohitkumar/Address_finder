from django.db import models

# Create your models here.

class Person(models.Model):
    name = models.CharField("Full name",max_length=50)
    email = models.EmailField("email",)
    address1 = models.CharField("Address line 1",max_length=50,blank=True)
    address2 = models.CharField("Address line 2",max_length=50,blank=True)
    zip_code = models.CharField("ZIP / Postal code",max_length=12,)
    city = models.CharField("City",max_length=1024,)

    


