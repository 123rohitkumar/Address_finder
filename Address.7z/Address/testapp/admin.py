from django.contrib import admin
from testapp.models import Person
from import_export.admin import ImportExportActionModelAdmin

# Register your models here.

admin.site.register(Person)

class PersonAdmin(ImportExportActionModelAdmin):
    list_display = ('name','email','address1','address2','zip_code','city')


